==========
Python API
==========


.. toctree::
    :maxdepth: 2

    parsing
    formatting
    styles
    plugins
